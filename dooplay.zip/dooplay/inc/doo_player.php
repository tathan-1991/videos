<?php
/*
* ----------------------------------------------------
* @author: Doothemes
* @author URI: https://doothemes.com/
* @copyright: (c) 2018 Doothemes. All rights reserved
* ----------------------------------------------------
*
* @since 2.1.8
*
*/

class DooPlayer{
	// Attributes
	public $postmeta;

	// The constructor
	public function __construct(){

        // Main postmeta
        $this->postmeta = 'repeatable_fields';

        // Actions
        add_action('save_post', array($this,'save'));
        add_action('admin_init', array($this,'add_metabox'), 1);

        // Ajax Actions
        add_action('wp_ajax_doo_player_ajax', array($this,'ajax'));
    	add_action('wp_ajax_nopriv_doo_player_ajax', array($this,'ajax'));
	}

	// Languages
	public function languages(){
		return array(
			__d('---------')			=> null,
			__d('Chinese')				=> 'cn',
			__d('Denmark')				=> 'dk',
			__d('Dutch')				=> 'nl',
			__d('English')				=> 'en',
			__d('English British')		=> 'gb',
			__d('Egypt')				=> 'egt',
			__d('French')				=> 'fr',
			__d('German')				=> 'de',
			__d('Indonesian')			=> 'id',
			__d('Hindi')				=> 'in',
			__d('Italian')				=> 'it',
			__d('Japanese')				=> 'jp',
			__d('Korean')				=> 'kr',
			__d('Philippines')			=> 'ph',
			__d('Portuguese Portugal')	=> 'pt',
			__d('Portuguese Brazil')	=> 'br',
			__d('Polish')				=> 'pl',
			__d('Romanian')				=> 'td',
			__d('Scotland')				=> 'sco',
			__d('Spanish Spain')		=> 'es',
			__d('Spanish Mexico')		=> 'mx',
			__d('Spanish Argentina')	=> 'ar',
			__d('Spanish Peru')			=> 'pe',
			__d('Spanish Chile')		=> 'pe',
			__d('Spanish Colombia')		=> 'co',
			__d('Sweden')				=> 'se',
			__d('Turkish')				=> 'tr',
			__d('Rusian')				=> 'ru',
			__d('Vietnam')				=> 'vn'
		);
	}


	// Player types
	public function type_player(){
		return array(
			__d('URL Iframe')			  => 'iframe',
			__d('URL MP4')				  => 'mp4',
			__d('ID or URL Google Drive') => 'gdrive',
			__d('Shortcode or HTML')	  => 'dtshcode',
		);
	}


	// Register Metabox
	public function add_metabox(){
		add_meta_box('repeatable-fields', __d('Video Player'), array($this,'view_metabox'), 'movies', 'normal', 'default');
		add_meta_box('repeatable-fields', __d('Video Player'), array($this,'view_metabox'), 'episodes', 'normal', 'default');
	}


	// Metabox Callbacks
	public function view_metabox(){
        global $post;
		$postmneta = get_post_meta($post->ID, $this->postmeta, true);
		wp_nonce_field('doo_player_editor_nonce', 'doo_player_editor_nonce');
        require get_parent_theme_file_path('/inc/parts/player_editor.php');
	}


	// Save metabox data
	public function save($post_id){
		if(!isset($_POST['doo_player_editor_nonce']) || !wp_verify_nonce($_POST['doo_player_editor_nonce'], 'doo_player_editor_nonce')) return;
		if(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
		if(!current_user_can('edit_post',$post_id)) return;

		// Meta data
		$antiguo = get_post_meta($post_id, $this->postmeta, true);
		$nuevo	 = array();
		$options = $this->type_player();
		$names	 = doo_isset($_POST,'name');
		$selects = doo_isset($_POST,'select');
		$idiomas = doo_isset($_POST,'idioma');
		$urls	 = doo_isset($_POST,'url');
		$count	 = count($names);

		// Serialized data
		for($i = 0; $i < $count; $i++){
			if ($names[$i] != ''):
				$nuevo[$i]['name'] = stripslashes(strip_tags($names[$i]));
				if(in_array($selects[$i], $options)) $nuevo[$i]['select'] = $selects[$i];
				else $nuevo[$i]['select'] = '';
				if(in_array($idiomas[$i], $idiomas)) $nuevo[$i]['idioma'] = $idiomas[$i];
				else $nuevo[$i]['idioma'] = '';
				if($urls[$i] == 'http://') $nuevo[$i]['url'] = '';
				else $nuevo[$i]['url'] = stripslashes($urls[$i]);
			endif;
		}
		if(!empty($nuevo) && $nuevo != $antiguo) update_post_meta($post_id, $this->postmeta, $nuevo);
		elseif (empty($nuevo) && $antiguo) delete_post_meta($post_id, $this->postmeta, $antiguo);
	}


	// Public Ajax
	public function ajax(){
		// POST Data
        $post_id = doo_isset($_POST,'post');
        $post_ty = doo_isset($_POST,'type');
        $play_nm = doo_isset($_POST,'nume');
		// Verify data
        if($post_id && $play_nm){
            // Get post meta
            switch ($post_ty) {
                case 'movie':
                    $postmeta = doo_postmeta_movies($post_id);
                    break;
                case 'tv':
                    $postmeta = doo_postmeta_episodes($post_id);
                    break;
            }
            // Compose Player
            $player = doo_isset($postmeta,'players');
            $player = maybe_unserialize($player);
            // compose data
            $pag = doo_compose_pagelink('jwpage');
            $url = ($play_nm != 'trailer') ? $this->ajax_isset($player, ($play_nm-1),'url') : false;
            $typ = ($play_nm == 'trailer') ? 'trailer' : $this->ajax_isset($player, ($play_nm-1),'select');
            // verify data
            if($typ){
                switch($typ) {
                    case 'iframe':
                        $code = "<if"."rame class='metaframe rptss' src='{$url}' frameborder='0' scrolling='no' allow='autoplay; encrypted-media' allowfullscreen></ifr"."ame>";
                        break;

                    case 'mp4':
                    case 'gdrive':
                        $code = "<if"."rame class='metaframe rptss' src='{$pag}?source=".urlencode($url)."&id={$post_id}&type={$typ}' frameborder='0' scrolling='no' allow='autoplay; encrypted-media' allowfullscreen></ifr"."ame>";
                    	break;

                    case 'trailer':
                        $code = doo_trailer_iframe(doo_isset($postmeta,'youtube_id'),1);
                    	break;

                    case 'dtshcode':
                        $code = do_shortcode($url);
                    	break;
                }
                // Return Player
                echo apply_filters('doo_player_ajax',$code,$url,$typ);
            }
        }
        // End Action
        wp_die();
	}


	// Data isset
	public function ajax_isset($data = array(), $n, $k){
		return (isset($data[$n][$k])) ? $data[$n][$k] : false;
	}


    // The destructor
	public function __destruct(){
		return false;
	}
}

new DooPlayer;
