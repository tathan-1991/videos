jQuery(document).ready(function($) {

	// Function generate data on click
	$('#generate_data_api').click(function() {

		var ids		= $('#ids').get(0).value
		var dbm		= DTapi.dbm
		var tmd		= DTapi.tmd
		var dbmkey  = DTapi.dbmkey
		var tmdkey  = '&api_key=' + DTapi.tmdkey
		var lang	= '&language='+ DTapi.lang +'&include_image_language='+ DTapi.lang +',null'
		var genres  = DTapi.genres
		var upload  = DTapi.upload
		var append  = '?append_to_response=images,trailers'
		var pda		= DTapi.pda
		$('#api_table').addClass( "hidden_api" )
		$('#loading_api').html('<p><span class="spinner"></span> '+ DTapi.loading +'</p>')

		// Verify PDA
		if( 1 == pda ) {

var dbmdata;
							// Inser IMDb Data
							$.each(dbmdata, function(key, val) {
								if (key == "rating") { $('#imdbRating').val(val) }
								if (key == "votes") { $('#imdbVotes').val(val) }
								if (key == "rated") { $('#Rated').val(val) }
								if (key == "country") { $('#Country').val(val) }
							});

							// GET TMDb
							$.getJSON( tmd + ids + append + lang + tmdkey , function(tmddata) {
								var valTit		= '';
								var valPlo		= '';
								var valImg		= '';
								var valBac		= '';
								var valupimg	= '';

								$('#loading_api').html('')
								$('#api_table').removeClass( "hidden_api" )

								$.each(tmddata, function(key, val) {
									$('input[name=' + key + ']').val(val);
									$('#message').remove();
									$("#verificador").show();
									if (key == "title") {
										$('label#title-prompt-text').addClass('screen-reader-text');
										$('input[name=post_title]').val(val);
									}
									if (key == "overview") {
										if (typeof tinymce != "undefined") {
											var editor = tinymce.get('content');
											if (editor && editor instanceof tinymce.Editor) {
												editor.setContent(val);
												editor.save({
													no_events: true
												});
											} else {
												$('textarea#content').val(val);
											}
										}
									}

									if (key == "poster_path") {
										$('input[name="dt_poster"]').val(val);
									}

									if (key == "poster_path") {
										if ( 1 == upload ) {
											if ( DTapi.post != 'edit') {
												valupimg += "https://image.tmdb.org/t/p/w500" + val + "";
												$('#postimagediv p').html("<ul><li><img class='dt_poster_preview' src='" + valupimg + "'/> </li></ul>");
											}
										}
									}

									if (key == "backdrop_path") {
										$('input[name="dt_backdrop"]').val(val);
									}

									if (key == "id") {
										$('input[name="idtmdb"]').val(val);
									}

									if (key == "release_date") {
										$('#new-tag-dtyear').val(val.slice(0, 4));
									}

									if (key == "trailers") {
										var tral = "";
										$.each(tmddata.trailers.youtube, function(i, item) {
											if (i > 0) return false;
											tral += "[" + item.source + "]";
										});
										$('input[name="youtube_id"]').val(tral);
									}

									if (key == "images") {
										var imgt = "";
										$.each(tmddata.images.backdrops, function(i, item) {
											if (i > 9) return false;
											imgt += item.file_path + "\n";
										});
										$('textarea[name="imagenes"]').val(imgt);
									}

									$.getJSON( tmd + ids + "/credits?" + tmdkey , function(tmddata) {
										$.each(tmddata, function(key, val) {
											if (key == "cast") {
												var cstm = cstml = "";
												$.each(tmddata.cast, function(i, item) {
													if (i > 9) return false;
													cstm += "[" + item.profile_path + ";" + item.name + "," + item.character + "]";
													cstml += "" + item.name + ", "; //
												});
												$('textarea[name="dt_cast"]').val(cstm);
												var valCast = "";
												$.each(tmddata.cast, function(i, item) {
													if (i > 9) return false;
													valCast += "" + item.name + ", "; //
												});
												$('#new-tag-dtcast').val(valCast);
											} else {
												var crew_d = crew_dl = "";
												var crew_w = crew_wl = "";
												$.each(tmddata.crew, function(i, item) {
													if (item.department == "Directing") {
														crew_d += "[" + item.profile_path + ";" + item.name + "]";
														crew_dl += "" + item.name + ", "; //
													}
												});
												$('input[name=dt_dir]').val(crew_d)
												$('#new-tag-dtdirector').val(crew_dl)
											}
										});
									});

								});
							});

		}
	});

	// Verify parameters
	if( DTapi.upload != 0 ) $('.import-upload-image').hide();
	if( DTapi.pda != 0 ) $('#generate_data_api').hide();
	if( DTapi.pda != 0 ) $('.import-upload-image').hide();
});
