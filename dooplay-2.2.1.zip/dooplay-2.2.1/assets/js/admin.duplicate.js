!function($){

    var Document = $(document)

    function dtDuplicateAjax(title,id) {
        var data = {
            action: "dt_duplicate",
            post_title: title,
            post_id: id
        }
        $.post(ajaxurl, data, function(respuesta) {
            $("#message").remove()
            $("#postbox-container-2").prepend("<div id=\"message\">"+respuesta+"</div>")
        })
    }

	function dtDuplicateAjax2(title,id) {
        var data = {
            action: "dt_duplicate",
            post_title: title,
            post_id: id
        }
        $.post(ajaxurl, data, function(respuesta) {
            $("#message2").remove()
            $("#postdivrich").prepend("<div id=\"message2\">"+respuesta+"</div>")
        })
    }

    Document.on("click","#comprovate",function(){
        var title = $("#title").val()
        var id    = $("#post_ID").val()
        dtDuplicateAjax(title, id)
    })

    Document.on("hover","#publish",function(){
        var title = $("#title").val()
        var id = $("#post_ID").val()
        dtDuplicateAjax2(title, id)
    })

    Document.on("click", "#title",function(){
        var title = $("#title").val()
        var id = $("#post_ID").val()
        dtDuplicateAjax2(title, id)
    })

}(jQuery);
